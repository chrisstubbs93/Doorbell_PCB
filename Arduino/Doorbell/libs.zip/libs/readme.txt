Put these subfolders in the arduino_install_location/libraries folder.

In arduino IDE go to file, properties
Paste following in to board manager url:
https://dl.espressif.com/dl/package_esp32_index.json, http://arduino.esp8266.com/stable/package_esp8266com_index.json
Select board as "ESP32 Dev Module"